Copyright (c) 2018, Liang Chen.

This zip file contains:

    - A CT average brain in the MNI space: CT_MNI_raw.nii.gz
    
    - A probability map of small vessel disease in the MNI space: SVD_prior_MNI.nii.gz
    
If you find they are useful in your work, please cite:

@inproceedings{chen2015identification,
  title={Identification of cerebral small vessel disease using multiple instance learning},
  author={Chen, Liang and Tong, Tong and Ho, Chin Pang and Patel, Rajiv and Cohen, David and Dawson, Angela C and Halse, Omid and Geraghty, Olivia and Rinne, Paul EM and White, Christopher J and others},
  booktitle={International Conference on Medical Image Computing and Computer-Assisted Intervention},
  pages={523--530},
  year={2015},
  organization={Springer}
}
